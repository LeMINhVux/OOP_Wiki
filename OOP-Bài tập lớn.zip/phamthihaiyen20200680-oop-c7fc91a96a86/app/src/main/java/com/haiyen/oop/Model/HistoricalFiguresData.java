package com.haiyen.oop.Model;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class HistoricalFiguresData implements ViewData {
    @SerializedName("ten")
    private String ten;

    @SerializedName("thong_tin")
    private List<String> thongTin;

    @SerializedName("noi_dung")
    private String noiDung;

    public HistoricalFiguresData(String ten, List<String> thongTin, String noiDung) {
        this.ten = ten;
        this.thongTin = thongTin;
        this.noiDung = noiDung;
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }

    @Override
    public String getTitle() {
        return ten;
    }

    @Override
    public String getContent() {
        String txt = "";
        if(thongTin != null){
            txt = String.join("\n", thongTin);
        }
        return txt + "\n\n\t" + noiDung + "\n\n";
    }
}
