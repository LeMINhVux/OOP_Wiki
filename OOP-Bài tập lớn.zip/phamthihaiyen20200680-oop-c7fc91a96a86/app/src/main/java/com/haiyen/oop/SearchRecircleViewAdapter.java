package com.haiyen.oop;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.haiyen.oop.Model.HistoryTimeData;
import com.haiyen.oop.Model.ViewData;

import java.util.List;

public class SearchRecircleViewAdapter extends RecyclerView.Adapter<SearchRecircleViewAdapter.SearchViewHolder>{
    private List<? extends ViewData> mData;
    private LayoutInflater mInflater;

    public SearchRecircleViewAdapter(List<? extends ViewData> mData, Context context) {
        this.mInflater = LayoutInflater.from(context);
        this.mData = mData;
    }

    @NonNull
    @Override
    public SearchRecircleViewAdapter.SearchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.search_row, parent, false);
        return new SearchViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SearchRecircleViewAdapter.SearchViewHolder holder, int position) {
        holder.title.setText(mData.get(position).getTitle());
        holder.content.setText(mData.get(position).getContent());
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class SearchViewHolder extends RecyclerView.ViewHolder {
        private TextView title;
        private TextView content;

        public SearchViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.search_row_title);
            content = itemView.findViewById(R.id.search_row_content);
        }
    }
}
