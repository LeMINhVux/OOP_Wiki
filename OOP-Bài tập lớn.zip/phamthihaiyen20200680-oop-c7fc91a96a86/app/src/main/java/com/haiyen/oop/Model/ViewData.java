package com.haiyen.oop.Model;

public interface ViewData {
    public String getTitle();

    public String getContent();
}
