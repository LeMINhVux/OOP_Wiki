package com.haiyen.oop.Model;

import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class HistoryTimeData implements ViewData {

    @Expose()
    @SerializedName("dia_danh_lien_quan")
    private List<String> diaDanhLienQuan = new ArrayList();

    @Expose()
    @SerializedName("thoi_ky")
    private List<SubHistoryTimeData> thoiKy = new ArrayList();

    @Expose()
    @SerializedName("noi_dung")
    private String noiDung;

    @Expose()
    @SerializedName("nhan_vat_lien_quan")
    private List<String> nhanVatLienQuan =new ArrayList();

    @Expose()
    @SerializedName("ten")
    private String ten;

    public HistoryTimeData() {
    }

    public HistoryTimeData(List<String> diaDanhLienQuan, List<SubHistoryTimeData> thoiKy, String noiDung, List<String> nhanVatLienQuan, String ten) {
        this.diaDanhLienQuan = diaDanhLienQuan;
        this.thoiKy = thoiKy;
        this.noiDung = noiDung;
        this.nhanVatLienQuan = nhanVatLienQuan;
        this.ten = ten;
    }

    public List<String> getDiaDanhLienQuan() {
        return diaDanhLienQuan;
    }

    public void setDiaDanhLienQuan(List<String> diaDanhLienQuan) {
        this.diaDanhLienQuan = diaDanhLienQuan;
    }

    public List<SubHistoryTimeData> getThoiKy() {
        return thoiKy;
    }

    public void setThoiKy(List<SubHistoryTimeData> thoiKy) {
        this.thoiKy = thoiKy;
    }

    public String getNoiDung() {
        return noiDung;
    }

    public void setNoiDung(String noiDung) {
        this.noiDung = noiDung;
    }

    public List<String> getNhanVatLienQuan() {
        return nhanVatLienQuan;
    }

    public void setNhanVatLienQuan(List<String> nhanVatLienQuan) {
        this.nhanVatLienQuan = nhanVatLienQuan;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }


    @Override
    public String getTitle() {
        return ten;
    }

    @Override
    public String getContent() {
        String txt = "";
        for (SubHistoryTimeData item:thoiKy
             ) {
            txt = txt + item.getTen() + ": "+ item.getNoiDung();
        }
        return "\tTóm tắt: " + noiDung
                + "\n\n\tCác thời kỳ: " + txt
                + noiDung+"\n\n\tĐịa danh liên quan: " + diaDanhLienQuan.toString()

                + "\n\n\tNhân vật liên quan: " + nhanVatLienQuan.toString()

        ;
    }
}

