package com.haiyen.oop.FileUtil;

import android.content.Context;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import org.json.simple.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class FileUtil {
    public static void saveJson(String name, JSONObject obj,Context context) {
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(name + ".json", Context.MODE_PRIVATE));
            outputStreamWriter.write(obj.toJSONString());
            outputStreamWriter.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void saveJson(String name, JSONArray obj,Context context) {
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(name + ".json", Context.MODE_PRIVATE));
            outputStreamWriter.write(obj.toJSONString());
            outputStreamWriter.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static JSONArray getJson(String fileName,Context context) {
        JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = new JSONArray();
        try {
            if(!fileExists(context,fileName + ".json")){
                return jsonArray;
            }
            InputStream inputStream = context.openFileInput(fileName + ".json");

            if(inputStream != null){
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);

                Object obj = jsonParser.parse(inputStreamReader);

                jsonArray =(JSONArray) obj;
            }
        } catch (FileNotFoundException | ParseException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return  jsonArray;
    }

    public static boolean fileExists(Context context, String filename) {
        File file = context.getFileStreamPath(filename);
        if(file == null || !file.exists()) {
            return false;
        }
        return true;
    }
}
