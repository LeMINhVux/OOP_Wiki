package com.haiyen.oop.Crawler;

public final class CrawlerConfig {
    public static final String BASE_URI = "https://nguoikesu.com";
    public static final String BASE_URI_2 = "https://vi.wikipedia.org";
}
