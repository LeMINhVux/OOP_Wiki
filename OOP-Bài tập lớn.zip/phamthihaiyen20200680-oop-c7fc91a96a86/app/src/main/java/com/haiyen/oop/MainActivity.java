package com.haiyen.oop;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.haiyen.oop.Crawler.Crawler;
import com.haiyen.oop.FileUtil.FileUtil;
import com.haiyen.oop.Model.FestivalData;
import com.haiyen.oop.Model.HistoricEventsData;
import com.haiyen.oop.Model.HistoricalFiguresData;
import com.haiyen.oop.Model.HistoryTimeData;
import com.haiyen.oop.Model.HistorycalSitesData;
import com.haiyen.oop.Model.SpinItemType;
import com.haiyen.oop.Model.ViewData;

import org.json.simple.JSONArray;

import java.lang.reflect.Type;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private EditText search;
    private Button searchButton;
    private ArrayList<? extends ViewData> searchResult;
    private ArrayList<? extends ViewData> searchData;
    private Spinner spinner;
    private RecyclerView recyclerView;
    private SearchRecircleViewAdapter adapter;

    private SpinItemType[] items = new SpinItemType[] {
            new SpinItemType("dong_lich_su", "Dòng lịch sử"),
            new SpinItemType("di_tich", "Di tích"),
            new SpinItemType("nhan_vat", "Nhân vật"),
            new SpinItemType("su_kien_lich_su", "Sự kiện lịch sử"),
            new SpinItemType("le_hoi_van_hoa", "Lễ hội văn hóa"),
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        search = findViewById(R.id.search);

        searchButton = findViewById(R.id.button);

        spinner = findViewById(R.id.spinner);

        recyclerView = findViewById(R.id.searchResult);

        spinner.setSelection(0);

        searchResult = new ArrayList<>();
        searchData = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SearchRecircleViewAdapter((ArrayList<? extends ViewData>) searchResult, this);
        recyclerView.setAdapter(adapter);

        ArrayList<String> titles = new ArrayList<>();

        for (SpinItemType i : items) {
            titles.add(i.getTitle());
        }

        spinner.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, titles));
        crawlData();
        initListener();
    }

    private void crawlData() {
        final Context ctx = getApplicationContext();
        final Crawler crawler = new Crawler(ctx, new ProgressDialog(this), () -> {
            // load data mặc định là dòng lịch sử sau khi tải xong dữ liệu
            loadData("dong_lich_su");
        });
        crawler.execute();
    }

    private void loadHistoryTimeData() {
        JSONArray data = FileUtil.getJson("dong_lich_su", getApplicationContext());
        Type historyTimeType = new TypeToken<ArrayList<HistoryTimeData>>() {
        }.getType();

        setViewData(new Gson().fromJson(data.toJSONString(), historyTimeType));
    }

    private void loadHistoricalSitesData() {
        JSONArray data = FileUtil.getJson("di_tich", getApplicationContext());
        Type type = new TypeToken<ArrayList<HistorycalSitesData>>() {
        }.getType();

        setViewData(new Gson().fromJson(data.toJSONString(), type));
    }

    private void loadHistoricalFiguresData() {
        JSONArray data = FileUtil.getJson("anh_hung_tieu_bieu", getApplicationContext());
        data.addAll(FileUtil.getJson("danh_nhan_van_hoa", getApplicationContext()));
        Type type = new TypeToken<ArrayList<HistoricalFiguresData>>() {
        }.getType();

        setViewData(new Gson().fromJson(data.toJSONString(), type));
    }

    private void loadHistoricEventsData() {
        JSONArray data = FileUtil.getJson("su_kien_lich_su", getApplicationContext());
        Type type = new TypeToken<ArrayList<HistoricEventsData>>() {
        }.getType();

        setViewData(new Gson().fromJson(data.toJSONString(), type));
    }

    private void loadFestivalData() {
        JSONArray data = FileUtil.getJson("le_hoi_van_hoa", getApplicationContext());
        Type type = new TypeToken<ArrayList<FestivalData>>() {
        }.getType();

        setViewData(new Gson().fromJson(data.toJSONString(), type));
    }

    private void initListener() {
        searchButton.setOnClickListener(v -> {
            ArrayList<Object> ls = new ArrayList();
            String input = search.getText().toString();
            for (Object item : searchData) {
                if (removeAccent(item.toString().toLowerCase()).contains(removeAccent(input.toLowerCase()))) {
                    ls.add(item);
                }
            }

            searchResult.clear();
            searchResult.addAll((ArrayList) ls);
            adapter.notifyDataSetChanged();

            search.clearFocus();
        });

        search.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                searchResult.clear();
                searchData.clear();
                adapter.notifyDataSetChanged();
                loadData(items[position].getFilename());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void loadData(String filename) {
        switch (filename) {
            case "dong_lich_su":
                loadHistoryTimeData();
                break;
            case "di_tich":
                loadHistoricalSitesData();
                break;
            case "nhan_vat":
                loadHistoricalFiguresData();
                break;
            case "su_kien_lich_su":
                loadHistoricEventsData();
                break;
            case "le_hoi_van_hoa":
                loadFestivalData();
                break;
        }
    }

    private void setViewData(ArrayList<? extends ViewData> data) {
        ArrayList<Object> ls = new ArrayList();

        for (Object i : data) {
            ls.add(i);
        }
        searchResult.addAll((ArrayList) data);
        searchData.addAll((ArrayList) data);
        adapter.notifyDataSetChanged();
    }

    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static String removeAccent(String s) {
        String temp = Normalizer.normalize(s, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        temp = pattern.matcher(temp).replaceAll("");
        return temp.replaceAll("đ", "d");
    }
}