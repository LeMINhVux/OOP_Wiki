package com.haiyen.oop.FormaterUtil;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

public class FormaterUtil {
    public static List<String> formatList(List<String> data) {
        return new ArrayList<String>(new LinkedHashSet<String>(data));
    }
}
