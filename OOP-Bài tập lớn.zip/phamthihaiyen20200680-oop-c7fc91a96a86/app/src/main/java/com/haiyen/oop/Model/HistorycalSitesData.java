package com.haiyen.oop.Model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class HistorycalSitesData implements ViewData{
    @SerializedName("ten")
    private String ten;

    @SerializedName("thong_tin")
    private List<String> thongTin;

    public HistorycalSitesData(String ten, List<String> thongTin) {
        this.ten = ten;
        this.thongTin = thongTin;
    }

    @Override
    public String getTitle() {
        return ten;
    }

    @Override
    public String getContent() {
        if (thongTin != null){
            return String.join("\n",thongTin) + "\n\n";
        }

        return "\n";
    }
}
