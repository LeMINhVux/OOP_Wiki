package com.haiyen.oop.Crawler;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;

import com.haiyen.oop.FileUtil.FileUtil;
import com.haiyen.oop.FormaterUtil.FormaterUtil;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.List;

public class Crawler extends AsyncTask<String, String, String> {
    private Context context;
    private ProgressDialog progress;
    private final String baseUri = CrawlerConfig.BASE_URI;
    private final String baseUri2 = CrawlerConfig.BASE_URI_2;
    private SuccessListener onCompleted;

    public Crawler(Context context, ProgressDialog progress, SuccessListener method) {
        this.context = context;
        this.progress = progress;
        onCompleted = method;
    }

    private void getHistoricalSites() {
        try {
            Document page = Jsoup.connect(baseUri + "/di-tich-lich-su").get();

            Elements linksElement = page.select("li.page-item > a");

            List<String> links = FormaterUtil.formatList(linksElement.eachAttr("href"));

            JSONArray jsonArr = new JSONArray();

            for (String path : links) {
                if (path.equals("#")) {
                    path = "/di-tich-lich-su";
                }

                Document body = Jsoup.connect(baseUri + path).get();

                Elements sitesPath = body.select("li.list-group-item > h3 > a");

                for (Element p : sitesPath) {
                    JSONObject jsonObj = new JSONObject();

                    jsonObj.put("ten", p.text());

                    Document bodyLink = Jsoup.connect(baseUri + p.attr("href")).get();

                    Elements get = bodyLink.getElementsByClass("infobox");

                    Element get1 = get.select("table > tbody").first();

                    if (get1 != null) {
                        Elements get2 = get1.select("tr");
                        List<String> sum = new ArrayList<>();

                        for (Element i : get2) {
                            final String title = i.select("th").text();
                            final String content = i.select("td").text();
                            String txt = "";
                            if (title != null) {
                                txt = txt + title;
                            }

                            String concat = "";

                            if (content != null && title != null && !title.equals("") && !content.equals("")) {
                                concat = ": ";
                            }

                            if (content != null) {
                                txt = txt + concat + content;
                            }

                            sum.add(txt);
                        }
                        jsonObj.put("thong_tin", sum);
                    }

                    jsonArr.add(jsonObj);

                    System.out.println(jsonObj.toJSONString());
                }

                FileUtil.saveJson("di_tich", jsonArr, context);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getHistoryTime() {
        try {
            // Tạo Documet từ URL
            Document page = Jsoup.connect(baseUri).get();

            // Tìm các phần tử, bao gồm và cả đệ quy dưới phần tử này, với tên thẻ là nav.
            Elements nav = page.getElementsByTag("nav");

            // tìm kiếm các phần tử a với thuộc tính href
            Elements links = nav.select("a[href]");

            // Khởi tạo List String là các thời đại lịch sử
            List<String> historyTime = new ArrayList<String>();

            // Lọc link theo mục
            for (Element element : links) {
                String link = element.attr("href");

                // Nếu Chuỗi link chứa 'dong-lich-su/' thì thêm link vào list histotyTime
                if (link.contains("dong-lich-su/")) {
                    historyTime.add(link);
                }
            }

            // Dùng LinkedHashSet để xóa trùng link
            List<String> data = FormaterUtil.formatList(historyTime);
            if (data.size() > 0) {

                JSONArray historyJsonList = new JSONArray();

                for (String val : data) {
                    // Khai báo JSONObject
                    JSONObject jsonObj = new JSONObject();

                    // Tạo Documet từ URL
                    Document doc = Jsoup.connect(baseUri + val).get();

                    // Tìm các phần tử, bao gồm và cả đệ quy dưới phần tử này, với tên class là blog
                    Elements body = doc.getElementsByClass("blog");

                    // Lấy tiêu đề với thẻ h1
                    // Nếu tiêu đề thẻ h1 != null thì put data vào JSONObject với key là name

                    if (body.first().getElementsByTag("h1").first() != null) {
                        jsonObj.put("ten", body.first().getElementsByTag("h1").first().text());
                    }

                    // Lấy nội dung
                    // Tìm các phần tử, bao gồm và cả đệ quy dưới phần tử này, với tên class là
                    // category-desc
                    Element cnt = doc.getElementsByClass("category-desc").first();

                    // Nếu khác null lấy tất cả các thẻ p và put vào JSONObject với key là content
                    if (cnt != null) {
                        Elements content = cnt.select("p");
                        jsonObj.put("noi_dung", content.text());
                    }

                    // Tìm các phần tử, bao gồm và cả đệ quy dưới phần tử này, với tên class là
                    // item-content
                    Elements subHistoryTimes = body.first().getElementsByClass("item-content");

                    // Tạo mảng JSONArray cho các khoảng thời gian lịch sử
                    JSONArray timeList = new JSONArray();

                    // Chạy vòng lặp for subHistoryTimes
                    for (Element sub : subHistoryTimes) {

                        // Khai báo JSONObject
                        JSONObject subObj = new JSONObject();

                        // Tìm các phần tử, bao gồm và cả đệ quy dưới phần tử này, với thẻ h2
                        Elements subName = sub.select("h2");

                        // Tìm các phần tử, bao gồm và cả đệ quy dưới phần tử này, với thẻ p
                        Elements subContent = sub.select("p");

                        // Check nếu subName!= null put vào subObj
                        if (subName != null) {
                            subObj.put("ten", subName.first().text());
                        }

                        if (subContent != null) {
                            subObj.put("noi_dung", subContent.text());
                        }

                        // add JSONObject được tạo vào mảng timeList
                        timeList.add(subObj);
                    }

                    // Put vào JSONObject vơi key là subHistoryTimes
                    jsonObj.put("thoi_ky", timeList);

                    Element more = body.first().select("p.readmore > a").first();
                    if (more != null) {
                        Document related = Jsoup.connect(CrawlerConfig.BASE_URI + more.attr("href")).get();

                        Elements relatedBody = related.select("div[itemprop=articleBody]");

                        Elements historicalFigures = relatedBody.select("a[href^=/nhan-vat/]");

                        Elements historicalSites = relatedBody.select("a[href^=/dia-danh/]");

                        jsonObj.put("nhan_vat_lien_quan", FormaterUtil.formatList(historicalFigures.eachText()));

                        jsonObj.put("dia_danh_lien_quan", FormaterUtil.formatList(historicalSites.eachText()));

                    }

                    historyJsonList.add(jsonObj);

                    System.out.println(jsonObj.toJSONString());

                }

                FileUtil.saveJson("dong_lich_su", historyJsonList, context);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getCulturalCelebrity() {
        try {

            Document page = Jsoup.connect(baseUri + "/danh-nhan-van-hoa?types[0]=1").get();

            Elements linksElement = page.select("li.page-item > a");

            List<String> links = FormaterUtil.formatList(linksElement.eachAttr("href"));

            JSONArray jsonArr = new JSONArray();

            for (String path : links) {
                if (path.equals("#")) {
                    path = "/danh-nhan-van-hoa?types[0]=1";
                }

                Document body = Jsoup.connect(baseUri + path).get();
                System.out.println(baseUri + path);

                Elements sitesPath = body.select("li.list-group-item > h3 >a");

                for (Element p : sitesPath) {
                    JSONObject jsonObj = new JSONObject();

                    jsonObj.put("ten", p.text());

                    Document pageItem = Jsoup.connect(baseUri + p.attr("href")).get();

                    Element info = pageItem.getElementsByClass("infobox").first();
                    Element contentAdd = pageItem.getElementsByClass("com-content-article__body").first();
                    if (info != null) {
                        ArrayList<String> sum = new ArrayList<>();
                        Elements noidung = info.select("tr");

                        for (Element i : noidung) {
                            final String title = i.select("th").text();
                            final String content = String.join(": ", i.select("td").eachText());
                            String txt = "";
                            if (title != null) {
                                txt = txt + title;
                            }

                            String concat = "";

                            if (content != null && title != null && !title.equals("") && !content.equals("")) {
                                concat = ": ";
                            }

                            if (content != null) {
                                txt = txt + concat + content;
                            }

                            sum.add(txt);
                        }

                        jsonObj.put("thong_tin", sum);
                    }
                    if (contentAdd != null) {
                        Elements noidungAdd = contentAdd.select("p");
                        jsonObj.put("noi_dung", noidungAdd.text());
                    }

                    jsonArr.add(jsonObj);
                    System.out.println(jsonObj.toJSONString());
                }

                FileUtil.saveJson("danh_nhan_van_hoa", jsonArr, context);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getTypicalHero() {
        try {

            Document page = Jsoup.connect(baseUri + "/anh-hung-dan-toc?types[0]=1").get();

            Elements linksElement = page.select("li.page-item > a");

            List<String> links = FormaterUtil.formatList(linksElement.eachAttr("href"));

            JSONArray jsonArr = new JSONArray();

            for (String path : links) {
                if (path.equals("#")) {
                    path = "/anh-hung-dan-toc?types[0]=1";
                }

                Document body = Jsoup.connect(baseUri + path).get();
                System.out.println(baseUri + path);

                Elements sitesPath = body.select("li.list-group-item > h3 >a");

                for (Element p : sitesPath) {
                    JSONObject jsonObj = new JSONObject();

                    jsonObj.put("ten", p.text());

                    Document pageItem = Jsoup.connect(baseUri + p.attr("href")).get();

                    Element info = pageItem.getElementsByClass("infobox").first();
                    Element contentAdd = pageItem.getElementsByClass("com-content-article__body").first();
                    if (info != null) {
                        ArrayList<String> sum = new ArrayList<>();
                        Elements noidung = info.select("tr");

                        for (Element i : noidung) {
                            final String title = i.select("th").text();
                            final String content = String.join(": ", i.select("td").eachText());
                            String txt = "";
                            if (title != null) {
                                txt = txt + title;
                            }

                            String concat = "";

                            if (content != null && title != null && !title.equals("") && !content.equals("")) {
                                concat = ": ";
                            }

                            if (content != null) {
                                txt = txt + concat + content;
                            }

                            sum.add(txt);
                        }

                        jsonObj.put("thong_tin", sum);
                    }
                    if (contentAdd != null) {
                        Elements noidungAdd = contentAdd.select("p");
                        jsonObj.put("noi_dung", noidungAdd.text());
                    }

                    jsonArr.add(jsonObj);
                    System.out.println(jsonObj.toJSONString());
                }

                FileUtil.saveJson("anh_hung_tieu_bieu", jsonArr, context);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void getHistoricEvents() {
        try {

            Document page = Jsoup
                    .connect(baseUri2 + "/wiki/Ni%C3%AAn_bi%E1%BB%83u_l%E1%BB%8Bch_s%E1%BB%AD_Vi%E1%BB%87t_Nam").get();
            Elements linksElement = page.select("div.mw-parser-output > p > a");
            List<String> links = FormaterUtil.formatList(linksElement.eachAttr("href"));

            JSONArray jsonArr = new JSONArray();
            for (String path : links) {

                Document body = Jsoup.connect(baseUri2 + path).get();

                Element name = body.getElementsByClass("mw-page-title-main").first();
                Elements content = body.select("div.mw-parser-output > p");

                JSONObject jsonObj = new JSONObject();
                if (name != null) {
                    jsonObj.put("ten", name.text());
                }
                if (content != null) {
                    jsonObj.put("noi_dung", content.text());
                }

                System.out.println(content.text());

                jsonArr.add(jsonObj);
                FileUtil.saveJson("su_kien_lich_su", jsonArr, context);
            }
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }

    private void getFestival() {
        try {

            Document page = Jsoup
                    .connect(baseUri2
                            + "/wiki/L%E1%BB%85_h%E1%BB%99i_Vi%E1%BB%87t_Nam")
                    .get();
            Elements table = page.select("div.mw-parser-output > table");
            Elements linksElement = table.get(1).select("tbody > tr");

            linksElement.remove(0);

            JSONArray jsonArr = new JSONArray();
            for (Element path : linksElement) {
                Elements linksItem = path.select("td");
                Document body = Jsoup.connect(baseUri2 + linksItem.get(2).select("a").attr("href")).get();
                JSONObject jsonObj = new JSONObject();
                jsonObj.put("ten", linksItem.get(2).select("a").text());
                jsonObj.put("nhan_vat", linksItem.get(4).text());
                System.out.println(linksItem.get(2).select("a").text());
                Element c = body.getElementsByClass("mw-parser-output").first();

                if (c != null) {
                    Element content = c.select("p").first();
                    if (content != null) {
                        jsonObj.put("noi_dung", content.text());
                        System.out.println(content.text());
                    }
                }

                jsonArr.add(jsonObj);
                FileUtil.saveJson("le_hoi_van_hoa", jsonArr, context);
            }
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
    }

    @Override
    protected void onPreExecute() {
        progress.setTitle("Tải dữ liệu");
        progress.setMessage("Đang tải dữ liệu...");
        progress.setCancelable(false);
        progress.show();
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... strings) {
        getHistoryTime();
        getHistoricalSites();
        getCulturalCelebrity();
        getTypicalHero();
        getHistoricEvents();
        getFestival();
        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        progress.dismiss();
        try {
            onCompleted.onSuccess();
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onPostExecute(s);
    }

    public interface SuccessListener {
        void onSuccess();
    }
}
