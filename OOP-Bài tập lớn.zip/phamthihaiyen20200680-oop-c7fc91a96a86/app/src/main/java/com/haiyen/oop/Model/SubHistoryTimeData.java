package com.haiyen.oop.Model;

import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SubHistoryTimeData {
    @Expose()
    @SerializedName("noi_dung")
    private String noiDung;

    @Expose()
    @SerializedName("ten")
    private String ten;

    public SubHistoryTimeData() {
    }

    public SubHistoryTimeData(String noiDung, String ten) {
        this.noiDung = noiDung;
        this.ten = ten;
    }

    public String getNoiDung() {
        return noiDung;
    }

    public void setNoiDung(String noiDung) {
        this.noiDung = noiDung;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }
}