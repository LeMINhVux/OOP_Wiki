
package com.haiyen.oop.Model;

import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TypicalHeroData implements ViewData {

    @SerializedName("thong_tin")
    private String thongTin;

    @SerializedName("noi_dung")
    private String noiDung;

    @SerializedName("ten")
    private String ten;

    public TypicalHeroData() {
    }

    public TypicalHeroData(String thongTin, String noiDung, String ten) {
        this.thongTin = thongTin;
        this.noiDung = noiDung;
        this.ten = ten;
    }

    public String getThongTin() {
        return thongTin;
    }

    public void setThongTin(String thongTin) {
        this.thongTin = thongTin;
    }

    public String getNoiDung() {
        return noiDung;
    }

    public void setNoiDung(String noiDung) {
        this.noiDung = noiDung;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    @Override
    public String toString() {
        return new Gson().toJson(this);
    }

    @Override
    public String getTitle() {
        return ten;
    }

    @Override
    public String getContent() {
        String txt = "";

        return ten + "\tTóm tắt: " + thongTin
                + "\n\n\tXem thêm: "
                + noiDung;

    }
}
